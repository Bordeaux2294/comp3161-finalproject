run finalproject 00

then finalproject0 ,then finalproject1 etc then final projectlast